﻿configuration WaitMaker 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory,xDisk, xNetworking, cDisk 
$seconds = 300
$log = "c:\windows\temp\WaitMaker.txt"
date >> $log
echo "WaitMaker start" >> $log
echo "Start sleep... $seconds" >> $log
start-sleep -s $seconds
date >> $log
echo "WaitMaker stop" >> $log

    Node localhost
    {
        
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }
        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }
        
        LocalConfigurationManager 
        {
            ActionAfterReboot = 'StopConfiguration'
        }
   }
} 